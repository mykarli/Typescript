export type todoType = {
  taskName: string;
  workDay: number;
};
